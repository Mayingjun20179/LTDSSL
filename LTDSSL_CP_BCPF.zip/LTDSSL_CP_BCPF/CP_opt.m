%%%%CP decomposition
function pre_tensor = CP_opt(train_tensor,option)
R = option(1);  %
train_tensor = sptensor(train_tensor);
U = cp_als(train_tensor,R);
P0 = ktensor(U);
pre_tensor = full(P0);

end