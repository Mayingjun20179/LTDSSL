This is the data and code for the paper "Logistic tensor decomposition with sparse subspace learning for prediction of multiple disease types of human-virus protein-protein interactions".  Please cite if you use this code.
This folder mainly includes LTDSSL, CP, BCPF code, these three methods are realized by matlab coding.

Data description:
"exper_data_datav3.mat" is the data format of matlab, which stores all experimental data of HMDD v3.2.
"HMDD3.2_processed" is the original data file of HMDD v3.2 from the literature "Huang F, Yue X, Xiong Z, Yu Z, Liu S, Zhang W: Tensor decomposition with relational constraints for predicting multiple types of microRNA-disease associations. Brief Bioinform 2021, 22(3)."


Code description:
"LTDSSL_opt.m" code for the LTDSSL method of this study
"CP_opt.m" indicates the CP decomposition model
"BCPF.m" represents the Bayesian CP Factorization with Automatic Rank Determination model
"mianZ.m" is the main function, and running this function can get the results of "CV_type" , "CV_triplet","CV_human protein","CV_virus protein".
"result" folder stores all the running results, and the results of each method are named after the method.


 Before running "mianZ.m", import "tensor_toolbox-v3.1" into the matlab running path.