clc
clear
%%%读取疾病名字
disname = readcell('di_name.csv');
disname(1,:) = [];  
size(disname,1)  %447
%%%%读取miRNA名字
miRNAname = readcell('mi_name.csv');
miRNAname(1,:) = [];  
size(miRNAname,1)  %713
%%%读取疾病的语义相似性数据
dis_sim = xlsread('Dis_sim.csv');
dis_sim(1,:) = [];
dis_sim(:,1) = [];
size(dis_sim)  %447   447
%%%读取circu.csv中关联数据
Type_circu = xlsread('circu.csv');
Type_circu(1,:) = [];
Type_circu(:,1) = [];
size(Type_circu)  %713   447

%%%读取epic.csv中关联数据
Type_epic = xlsread('epic.csv');
Type_epic(1,:) = [];
Type_epic(:,1) = [];
size(Type_epic)  %713   447

%%%读取genetic.csv中关联数据
Type_genetic = xlsread('genetic.csv');
Type_genetic(1,:) = [];
Type_genetic(:,1) = [];
size(Type_genetic)  %713   447


%%%读取target.csv中关联数据
Type_target = xlsread('genetic.csv');
Type_target(1,:) = [];
Type_target(:,1) = [];
size(Type_target)  %713   447


%%%读取tissue.csv中关联数据
Type_tissue = xlsread('tissue.csv');
Type_tissue(1,:) = [];
Type_tissue(:,1) = [];
size(Type_tissue)  %713   447


%%%%%%%%%%%%%%%%%%数据整合
inter_tensor_exp = zeros(713,447,5);
inter_tensor_exp(:,:,1) = Type_circu;
inter_tensor_exp(:,:,2) = Type_epic;
inter_tensor_exp(:,:,3) = Type_genetic;
inter_tensor_exp(:,:,4) = Type_target;
inter_tensor_exp(:,:,5) = Type_tissue;


exper_data_datav3.inter_tensor_exp = inter_tensor_exp;
exper_data_datav3.dis_sim = dis_sim;

save exper_data_datav3 exper_data_datav3;


