%%%%张量分解（不用辅助信息）
function pre_tensor = CP_opt(train_tensor,option)
R = option(1);  %表示因子矩阵的维度
train_tensor = sptensor(train_tensor);
U = cp_als(train_tensor,R);
P0 = ktensor(U);
pre_tensor = full(P0);

end