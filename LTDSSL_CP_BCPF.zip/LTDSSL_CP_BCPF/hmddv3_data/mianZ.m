%%%%%%%%%%%%%LTDSSL,CP,BCPFARD,5-fold
clc
clear

%%%Import experimental data
load('exper_data_datav3.mat')

%%%%%%%%%%%%%%%%%%%%%%%%LTDSSL
load('exper_data_datav3.mat')
method_name = 'LTDSSL';
main_cv(exper_data_datav3,method_name,'cv_type');    %%%%CV_type
main_cv(exper_data_datav3,method_name,'cv_triplet');   %%%%CV_triplet


%%%%%%%%%%%%%%%%%%%%%%%%CP
method_name = 'CP';
main_cv(exper_data_datav3,method_name,'cv_type');    %%%%CV_type
main_cv(exper_data_datav3,method_name,'cv_triplet');   %%%%CV_triplet



%%%%%%%%%%%%%%%%%%%%%%%%BCPF
method_name = 'BCPFARD';
main_cv(exper_data_datav3,method_name,'cv_type');    %%%%CV_type
main_cv(exper_data_datav3,method_name,'cv_triplet');   %%%%CV_triplet
