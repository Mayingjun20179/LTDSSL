This is the data and code for the paper "Logistic tensor decomposition with sparse subspace learning for prediction of multiple disease types of human-virus protein-protein interactions".  Please cite if you use this code.
This folder mainly includes LTDSSL, CP, BCPF code, these three methods are realized by matlab coding.

Data description:
"exper_data.mat" is the data format of matlab, which stores all the data of this experiment
"Experimental_data_all.xlsx" is the data file of this study, including human (virus) protein ID, human (virus) protein sequence, human (virus) protein pseAAC feature, human (virus) protein CTD feature, and 6 Human (viral) protein association in central vascular disease.

Code description:
"LTDSSL_opt.m" code for the LTDSSL method of this study
"CP_opt.m" indicates the CP decomposition model
"BCPF.m" represents the Bayesian CP Factorization with Automatic Rank Determination model
"mianZ.m" is the main function, and running this function can get the results of "CV_type" , "CV_triplet","CV_human protein","CV_virus protein".
"result" folder stores all the running results, and the results of each method are named after the method.

 Before running "mianZ.m", import "tensor_toolbox-v3.1" into the matlab running path.