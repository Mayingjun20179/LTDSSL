该文件夹主要包含“TFAI”，“TDRC”，“WeightTDAIGN”，“TFLP”的代码，这些代码是通过python语言编程实现的。

其中：
“TDRC_CV.py”表示TDRC方法交叉实验的主函数。
“TFAI_CV.py”表示TFAI方法交叉实验的主函数。
“TFLP_CV.py”表示TFLP方法交叉实验的主函数。
“WeightTDAIGN_CV.py”表示WeightTDAIGN方法交叉实验的主函数。

分别运行这四个以“CV”结尾的python函数，可以得到关于 "CV_type" , "CV_triplet","CV_human protein","CV_virus protein"的结果。
运行这些文件之前，需要安装numpy，tensorly，pandas，math，csv，heapq，time包。




The folder mainly contains the code of "TFAI", "TDRC", "WeightTDAIGN", "TFLP", which is implemented through the python programming language.

Where:

"TDRC_CV.py" represents the main function of the TDRC method crossover experiment.
"TFAI_CV.py" represents the main function of the TFAI method crossover experiment.
"TFLP_CV.py" represents the main function of the TFLP method cross experiment.
"WeightTDAIGN_CV.py" represents the main function of the intersection experiment of the WeightTDAIGN method.

Running each of these four python files ending in" CV "yields results for "CV_type"," CV_triplet","CV_human protein", and "CV_virus protein".

Before running these files, you need to install the numpy, tensorly, pandas, math, csv, heapq, and time packages.

