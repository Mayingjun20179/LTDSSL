import csv
import os.path as osp
import numpy as np
import scipy.io as sio

class GetData(object):
    def __init__(self, root, human_num=713, virus_num=447):
        super().__init__()
        self.root = osp.join(root, 'HMDD3.2_processed')
        self.human_num = human_num
        self.virus_num = virus_num
        self.human_sim, self.virus_sim, self.type_tensor = self.__get_data__()
        self.human_num = self.human_sim.shape[0]
        self.virus_num = self.virus_sim.shape[0]

    def __get_data__(self):
        load_fn = sio.loadmat('exper_data.mat')
        type_association_matrix = load_fn['exper_data']['inter_tensor_exp'][0,0]
        human_sim = load_fn['exper_data']['human_paac_sim'][0,0]
        virus_sim = load_fn['exper_data']['virus_paac_sim'][0,0]
        return human_sim,virus_sim,type_association_matrix