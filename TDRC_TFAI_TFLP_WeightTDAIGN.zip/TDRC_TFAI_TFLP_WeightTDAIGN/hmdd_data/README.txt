The folder mainly contains the code of "TFAI", "TDRC", "WeightTDAIGN", "TFLP", which is implemented through the python programming language.

Data description:
"HMDD3.2_processed" is the original data file of HMDD v3.2 from the literature "Huang F, Yue X, Xiong Z, Yu Z, Liu S, Zhang W: Tensor decomposition with relational constraints for predicting multiple types of microRNA-disease associations. Brief Bioinform 2021, 22(3)."

Code description:
"TDRC_CV.py" represents the main function of the TDRC method crossover experiment.
"TFAI_CV.py" represents the main function of the TFAI method crossover experiment.
"TFLP_CV.py" represents the main function of the TFLP method cross experiment.
"WeightTDAIGN_CV.py" represents the main function of the intersection experiment of the WeightTDAIGN method.


"result" folder stores all the running results, and the results of each method are named after the method.


Running each of these four python files ending in" CV "yields results for "CV_type"," CV_triplet","CV_human protein", and "CV_virus protein".

Before running these files, you need to install the numpy, tensorly, pandas, math, csv, heapq, and time packages.

